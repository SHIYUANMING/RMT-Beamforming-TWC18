%function [Wsolution,feasible,solving_time, cvx_slvitr] = powermin_cvx(params)
function [Wsolution,feasible] = powermin_cvx(params)

%prob_to_socp: maps PARAMS into a struct of SOCP matrices
%input struct 'parms' has the following fields:
%params.L;   %'L': # RRHs
%params.K;    %'K': # MUs
%params.N_set;  %set of antennas at all the RRHs
%params.delta_set; %set of noise covariance

%%%%%%%%%%%%%%Problem Instances%%%%%%%%%%%%%
%params.r_set;  %set of SINR thresholds
%params.H;  %Channel Realization
%params.P_set;   %set of transmit power constraints at all the RRHs

%%%%%%%%Problem Data%%%%%%%
K=params. K;
L=params. L;
N_set=params.N_set;
weight_matrix=kron(diag(params.weight.^(1/2)),eye(params.N));

%tic
cvx_begin 
variable W(sum(params.N_set), K) complex;   %Variable for N x K beamforming matrix
minimize norm(weight_matrix*W,'fro')
subject to
     
     for k=1:K        %%%%%%%%%QoS constraints
      %%
         norm([params.H(:,k)'*W, params.delta_set(k)],'fro')<=sqrt(1+1/params.r_set(k))*real(params.H(:,k)'*W(:,k));   
     end
   %  cvx_end
   
    output = evalc('cvx_end');
    
%%
     if  strfind(cvx_status,'Solved') 
         feasible=true;
         Wsolution=W;
     else
         feasible=false;
         Wsolution=[];
     end