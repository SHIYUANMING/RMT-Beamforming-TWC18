clc;clear all;
%cvx_solver sdpt3

%%Problem Data%%%%%%%%%%%%%%%%%%%%%%%%%%%%
L=5; K=5; N=30; Area=4*10^3; N_set=N*ones(L,1);
Q=6;
%Q=[0:2:10]';  %QoS in dB
LC=100;  % # loops for channel realizations
max_iter=21; 
finitesys=1; largesys=1;
alg_p=1; epsilon=10^(-3); % lp norm

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
params.L=L;   %'L': # RRHs
params.K=K;    %'K': # MUs
params.N=N;
params.N_set=N_set;  %set of antennas at all the RRHs
params.delta_set=1*ones(K,1); %set of noise covariance
params.P_set=10^(0)*ones(L,1);   %set of transmit power constraints at all the RRHs

%D =channel_largefading(L, K, Area);
%D=ones(L,K);
load('D.mat');
% for ss=1:LC   % generate channel
%     H(:,:,ss)=channel_smallfading(L, K, N_set, D);
% end
load('H.mat');
params.D=D;
 
params.r_set=10^(Q(1)/10)*ones(K,1);  %set of SINR thresholds 
params_finite=params; 
TotalPower_large_temp=0; TotalPower_finite_temp=0;
TotalPower_large=0; TotalPower_finite=0;

%% Large System Analysis
params_large=params_finite;
params_large.weight=ones(L,1);  % initialize

for iter=1:max_iter
    [lambda_largesys, power_largesys, z_det] = powermin_largesys(params_large);  % large system analysis
    for l=1:L
        weight_large_temp(l)=alg_p/2*(z_det(l)+epsilon^2)^(alg_p/2-1);
        power_large_temp(l)=(z_det(l)+epsilon^2)^(alg_p/2);
    end
    params_large.weight=weight_large_temp; % update weight
    TotalPower_large(iter)=sum(power_large_temp);
end

%% Finite System Analysis
for lp=1:LC
    params_finite.weight=ones(L,1);  % initialize
    params_finite.H=H(:,:,lp);
    for iter=1:max_iter
        [Wsolution_finitesys, lambda_finitesys, power_finitesys] = powermin_finitesys(params_finite);  % finite system analysis
        for l=1:L
                    weight_finite_temp(l)=alg_p/2*(norm(Wsolution_finitesys(sum(params.N_set(1:l-1))+1:sum(params.N_set(1:l)),:),'fro')^2+epsilon^2)^(alg_p/2-1);
                    power_finite_temp(l)=(norm(Wsolution_finitesys(sum(params.N_set(1:l-1))+1:sum(params.N_set(1:l)),:),'fro')^2+epsilon^2)^(alg_p/2);
        end  
                params_finite.weight=weight_finite_temp; % update weight
                TotalPower_finite(iter,lp)=sum(power_finite_temp);
    end
end
    
    TotalPower_finite_final=sum(TotalPower_finite,2)/LC;
    
    plot([0:max_iter-1],sqrt(5.6*4)*TotalPower_finite_final,'r-s','LineWidth',1.5, 'MarkerSize',10);
    hold on;
    plot([0:max_iter-1],sqrt(5.6*4)*TotalPower_large,'b-x','LineWidth',1.5, 'MarkerSize',10);
    hold on;
    
    h=legend('Finite System Analysis', 'Large System Analysis', 'fontsize',12,'fontweight','b','fontname','helvetica');
    xlabel('Iteration','fontsize',14,'fontweight','b','fontname','helvetica');
    ylabel('Objective Values','fontsize',14,'fontweight','b','fontname','helvetica');
    
    %save('TotalPower_finite_final.mat','TotalPower_finite_final');
    %save('TotalPower_large.mat','TotalPower_large');