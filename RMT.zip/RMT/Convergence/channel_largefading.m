function [D] =channel_largefading(L, K, Area)
% Generate channel matrix

%INPUT:
%L      =# RRHs
%K      =# MUs
%N_set    =# antennas at each RRH
%Area      =length of the area

%OUTPUT:
% D     = (L x K) large-scale fading coefficients

%%%%%%%%%%%%%%%%Network Realization%%%%%%%%%%%%%%%%%%%%%%%%
 U_position=Area.*(rand(2,K)-0.5);  %% user positions
 B_position=Area.*(rand(2,L)-0.5);  %%RRH positions

 %%%%%Generate Large-Scale Fading%%%%%%%%%%%%%
for k=1:K
    for l=1:L
        d=(norm(B_position(:,l)-U_position(:,k))+10);
        D(l,k)=4.4*10^(5)/(d^(1.88)*10^(normrnd(0,6.3)/20));
        %D(l,k)=1;
    end
end
