function [Wsolution_finitesys,lambda, power] = powermin_finitesys(params)
%%%%%%%%Problem Data%%%%%%%
K=params. K;
L=params. L;
N=params.N;
N_set=params.N_set;
H=params.H;
Q=kron(diag(params.weight),eye(N));
r_set=params.r_set;

%% fixed-point iteration

i=1; lambda_temp=ones(1,K); error(i)=10^99;
while error(i)>=10^(-8)
    for k=1:K
        lambda(k)=N*L*inv((1+1/r_set(k))*H(:,k)'*inv(Q+(1/(L*N))*H*diag(lambda_temp)*H')*H(:,k));
    end
    error(i+1)=norm(lambda-lambda_temp);
    i=i+1;
    lambda_temp=lambda;
end

for k=1:K
    Wsolution_direction(:,k)=inv(Q+(1/(L*N))*H*diag(lambda)*H')*H(:,k); 
end

for i=1:K
    for j=1:K
        if i==j
            M(i,j)=(1/(L*N*r_set(i))*(abs(H(:,i)'*Wsolution_direction(:,i))^2/norm(Wsolution_direction(:,i))^2));
        else
            M(i,j)=-(1/(L*N)*(abs(H(:,i)'*Wsolution_direction(:,j))^2/norm(Wsolution_direction(:,j))^2));
        end
    end
end
power=inv(M)*params.delta_set;

for k=1:K
    Wsolution_finitesys(:,k)=sqrt(power(k)/(L*N))*Wsolution_direction(:,k)./norm(Wsolution_direction(:,k));
end
