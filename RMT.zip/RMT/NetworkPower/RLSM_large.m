function [z_sparse] = RLSM_large(params_large)
alg_p=params_large.alg_p;
epsilon=params_large.epsilon;

for iter=1:11
    [lambda_large, power_large, z_det] = powermin_largesys(params_large);  % large system analysis
    for l=1:params_large.L
        weight_large_temp(l)=params_large.weight(l)*alg_p/2*(z_det(l)+epsilon^2)^(alg_p/2-1);
    end
    params_large.weight=weight_large_temp; % update weight
end

z_sparse=z_det;
    