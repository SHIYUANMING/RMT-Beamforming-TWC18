function [P_optimal, A_optimal] = GSBF(params, z_sparse)

L=params.L;
Pc=params.Pc;
N1=params.N1;
N_set=params.N_set;
H_orignal=params.H_orignal;
coeff=params.coeff;

%%%RRH Ordering
     %%
     for l=1:L    
         if l==1
             g(l) = norm(params.H(1:N_set(1),:),'fro');
         else
             g(l) = norm(params.H(sum(N_set(1:l-1))+1:sum(N_set(1:l)),:),'fro');
         end
     end
     
     SparseW=sqrt(Pc)./g; %1 x L Group sparse ording weights
     
     [BS,BS_index]=sort(z_sparse'./SparseW);   %RRH ordering
     
     D_set=[]; A_set=BS_index;  %A_set: active RRH set, D_set: inactive RRH set
     D_optimal=[]; A_optimal=BS_index;  % optimal active and inactive RRH set 
     
     %%%%%%%%%%%%%%%%%%Process Deflation Procedure%%%%%%%%%%%%%%%%%%%%%%
     %%
     for A=0:L-2
         
         %% Updata Problem Data 
         params.L=length(A_set);   %'L': # RRHs
         params.N_set=N1*ones(params.L,1);  %set of antennas at all the RRHs
         params.P_set=10^(0)*ones(params.L,1);   %set of transmit power constraints at all the RRHs
         
         %% Updata Channel
         H_index=N1*A_set;
         if N1>1
         for nn=1:(N1-1)
             H_index=[H_index, N1*A_set-nn*ones(length(A_set),1)'];
         end
         end
         params.H = H_orignal(H_index,:);
         
         
         %% Call CVX
         [Wsolution,feasible] = powermin_cvx(params);  %power minimization given the active RRH set
         
         if feasible==1
             P_optimal=coeff(1)*norm(Wsolution,'fro')^2+sum(Pc(A_set));  %network power consumption
             D_optimal=D_set; A_optimal=A_set;
             D_set=[D_set, BS_index(A+1)];  %%%process next selection: updata active RRH set and number
             A_set=setdiff([1:L],D_set); 
         elseif feasible==0&isempty(D_set)==1   %infeasible
             break;  
         else feasible==0&isempty(D_set)==0   %infeasible
             D_set=setdiff(D_set,D_set(length(D_set)));   %%%%%%Backup one step to recoder the final feasible set
             A_set=setdiff([1:L], D_set);
             break,
         end
     end