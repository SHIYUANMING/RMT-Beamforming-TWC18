function [lambda, power, z_det] = powermin_largesys(params)

%%Problem Data%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K=params. K;
L=params. L;
N=params.N1;
%H=params.H;
D=params.D;
r_set=params.r_set;
weight=params.weight;
Q=kron(diag(params.weight),eye(N));

%% deterministic equivalent for lambdas
i=1; eta_temp=ones(1,L); error(i)=10^99;
while error(i)>=10^(-8)
    for l=1:L
        
        temp1=r_set./(1+r_set);
        temp2=(1/L)*eta_temp*D;
        eta(l)=((1/(N*L))*sum(D(l,:).*temp1'./temp2)+weight(l))^(-1);
        
    end
    error(i+1)=norm(eta-eta_temp);
    i=i+1;
    eta_temp=eta;
end

lambda=r_set'./((1/L)*eta*D); 

%% deterministic equivalent for powers

m=(1/L)*eta*D; m=m';

X=(1/L)*D'*diag(eta.^2)*D;
J=(1/(N*L))*X*diag(lambda.^2./(1+r_set').^2);

M_der=inv(eye(K)-J)*X;

XX=sum((1/L)*D'*diag(eta.^2),2);
m_der=inv(eye(K)-J)*XX;

%%
for i=1:K
    for j=1:K
        if i==j
            DD(i,j)=m(i)^2/(m_der(i)*r_set(i));
        else
            DD(i,j)=-1/(N*L*(1+r_set(j))^2)*M_der(i,j)/m_der(j);
        end
    end
end

power=inv(DD)*params.delta_set; 

%% deterministic for group beamformers
% XXX=(1/L)*diag(eta.^2)*D;
% MM_der=XXX*inv(eye(K)-J);
% z_det=(1/(L*N))*MM_der*(power./m_der); % 

XXX=(1/L)*diag(eta.^2)*D;
MM_der=inv(eye(K)-J)*XXX';
z_det=(1/(L*N))*((power./m_der))'*MM_der; % deterministic for L group beamforming coefficients

%%
% for k=1:K
%     Wsolution_direction(:,k)=inv(Q+(1/(L*N))*H*diag(lambda)*H')*H(:,k); 
% end
% for k=1:K
%     Wsolution(:,k)=sqrt(power(k)/(L*N))*Wsolution_direction(:,k)./norm(Wsolution_direction(:,k));
% end