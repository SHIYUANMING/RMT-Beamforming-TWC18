function [z_sparse] = RLSM_finitesys(params_finite)
alg_p=params_finite.alg_p;
epsilon=params_finite.epsilon;

for iter=1:11
    [Wsolution_finitesys, lambda_finitesys, power_finitesys] = powermin_finitesys(params_finite);  % finite system analysis
    for l=1:params_finite.L
        weight_finite_temp(l)=params_finite.weight(l)*alg_p/2*(norm(Wsolution_finitesys(sum(params_finite.N_set(1:l-1))+1:sum(params_finite.N_set(1:l)),:),'fro')^2+epsilon^2)^(alg_p/2-1);
    end
    params_finite.weight=weight_finite_temp; % update weight
end

for l=1:params_finite.L
    z_sparse(l)=norm(Wsolution_finitesys(sum(params_finite.N_set(1:l-1))+1:sum(params_finite.N_set(1:l)),:),'fro')^2;
end
    