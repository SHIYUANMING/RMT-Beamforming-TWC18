clc;clear all;
%cvx_solver mosek

% cvx_solver scs
% cvx_solver_settings('SCALE',20, 'MAX_ITERS', 10^4);

%%Problem Data%%%%%%%%%%%%%%%%%%%%%%%%%%%%
L=5; K=6; N1=10; Area=2*10^3; N_set=N1*ones(L,1);

Pc=5.6+2*[1:1:L];    % fronthaul network power consumption
coeff=4*ones(1,L);  % power amplifer coefficients
params.alg_p=0.5; params.epsilon=10^(-3);

Q=[0:3:12]';  % QoS in dB
LD=1;
LC=2; % #loops for channel realizarions
cvx=1; finite=1; large=1;
%%%%%%initialize results%%%%%%%%%%%%%%%%%%%%%%
%%
SU_counter=0; %count the success of channel realizations
A_number_temp=0;  TotalPower_temp=0;  TransmitPower_temp=0;
A_number_finitesys_temp=0;  TotalPower_finitesys_temp=0;  TransmitPower_finitesys_temp=0;
A_number_large_temp=0;  TotalPower_large_temp=0;  TransmitPower_large_temp=0;

for dd=1:LD
    %D(:,:,dd) =channel_largefading(L, K, Area);
    load('D.mat');
    for ss=1:LC
        H(:,:,dd,ss)=channel_smallfading(L, K, N_set, D);
    end
end
%load('D.mat','D'); load('H.mat','H');

%% Problem Data
params.L=L;   %'L': # RRHs
params.N_set=N_set;  %set of antennas at all the RRHs
params.N1=N1;
params.P_set=10^(0)*ones(L,1);   %set of transmit power constraints at all the RRHs
        
params.K=K;    %'K': # MUs
params.delta_set=1*ones(K,1); %set of noise covariance
params.Pc=Pc;
params.coeff=coeff;

for ld=1:LD
for lp=1:LC
    
    H_orignal=H(:,:,ld,lp);
    params.H_orignal=H_orignal;
    
    for lq=1:length(Q)
        
        params.H=H_orignal;
        params.r_set=10^(Q(lq)/10)*ones(K,1);  %set of SINR thresholds   
        
        params.weight = sqrt(Pc);  P_optimal=10^100;      
%% L_l2 norm minimization
if cvx==true
[feasible_cvx,z_sparse] = sparsebeamforming(params); %sparse beamforming solutions
end

%% RLSM finite system analysis
if finite==true
params_finite=params;
[z_finitesys_sparse] = RLSM_finitesys(params_finite);
end

%% RLSM large system analysis
if large==true
params_large=params; params_large.D=D(:,:,ld);
[z_large_sparse] = RLSM_large(params_large);
end

%% RRH Selection
 if feasible_cvx==1
     if cvx==true
     [P_optimal, A_optimal] = GSBF_con(params, z_sparse);
     end
     
     if finite==true
     [P_optimal_finitesys, A_optimal_finitesys] = GSBF(params, z_finitesys_sparse');
     end
     
     if large==true
     [P_optimal_large, A_optimal_large] = GSBF(params, z_large_sparse');
     end
 end
 
 %% Results for each SNR with L12-norm
 if cvx==true
 TotalPower(lq)=P_optimal;
 A_number(lq)=size(A_optimal,2);
 TransmitPower(lq)=P_optimal-sum(Pc(A_optimal));
 end
 
 %% Results for each SNR with RLSM in finite system analysis
 if finite==true
 TotalPower_finitesys(lq)=P_optimal_finitesys;
 A_number_finitesys(lq)=size(A_optimal_finitesys,2);
 TransmitPower_finitesys(lq)=P_optimal_finitesys-sum(Pc(A_optimal_finitesys));
 end
 
  %% Results for each SNR with RLSM in large system analysis
 if large==true
 TotalPower_large(lq)=P_optimal_large;
 A_number_large(lq)=size(A_optimal_large,2);
 TransmitPower_large(lq)=P_optimal_large-sum(Pc(A_optimal_large));
 end
    
    end
 
%%
    if norm(TotalPower)<10^100
     SU_counter=SU_counter+1;
     
     if cvx==true
     A_number_temp=A_number_temp+A_number;
     TotalPower_temp=TotalPower_temp+TotalPower;
     TransmitPower_temp=TransmitPower_temp+TransmitPower;  
     end
     
     if finite==true
     A_number_finitesys_temp=A_number_finitesys_temp+A_number_finitesys;
     TotalPower_finitesys_temp=TotalPower_finitesys_temp+TotalPower_finitesys;
     TransmitPower_finitesys_temp=TransmitPower_finitesys_temp+TransmitPower_finitesys; 
     end
     
     if large==true
     A_number_large_temp=A_number_large_temp+A_number_large;
     TotalPower_large_temp=TotalPower_large_temp+TotalPower_large;
     TransmitPower_large_temp=TransmitPower_large_temp+TransmitPower_large; 
     end
     
    end
    
end
end

if cvx==true
A_number=A_number_temp./SU_counter;
TotalPower=TotalPower_temp./SU_counter;
TransmitPower=TransmitPower_temp./SU_counter;
end

if finite==true
A_number_finitesys=A_number_finitesys_temp./SU_counter;
TotalPower_finitesys=TotalPower_finitesys_temp./SU_counter;
TransmitPower_finitesys=TransmitPower_finitesys_temp./SU_counter;
end

if large==true
A_number_large=A_number_large_temp./SU_counter;
TotalPower_large=TotalPower_large_temp./SU_counter;
TransmitPower_large=TransmitPower_large_temp./SU_counter;
end

% save('A_number.mat','A_number');
% save('TotalPower.mat','TotalPower');
% save('TransmitPower.mat','TransmitPower');

% save('A_number_finitesys.mat','A_number_finitesys');
% save('TotalPower_finitesys.mat','TotalPower_finitesys');
% save('TransmitPower_finitesys.mat','TransmitPower_finitesys');

% save('A_number_large.mat','A_number_large');
% save('TotalPower_large.mat','TotalPower_large');
% save('TransmitPower_large.mat','TransmitPower_large');

if cvx==true
plot(Q,TotalPower,'r-d','LineWidth',1.5, 'MarkerSize',10); %Proposed Bi-section GSBF
hold on;
end
if finite==true
plot(Q,TotalPower_finitesys,'b-x','LineWidth',1.5, 'MarkerSize',10); %Proposed Bi-section GSBF
hold on;
end
if large==true
plot(Q,TotalPower_large,'g-o','LineWidth',1.5, 'MarkerSize',10); %Proposed Bi-section GSBF
hold on;
end

A_number

h=legend('GSBF','RLSM','RLSM with Large');
xlabel('Target SINR [dB]','fontsize',12,'fontweight','b','fontname','helvetica');
ylabel('Average Network Power Consumption [W]','fontsize',14,'fontweight','b','fontname','helvetica');